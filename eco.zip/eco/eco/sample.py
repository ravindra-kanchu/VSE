import os
import random
import shutil

# Paths to your folders
tshirt_folder = r'eco\eco\static\image\image\product\tshirt'
source_folder = r"C:\Users\Ravindra Kanchu\Desktop\tshirt"  # The folder with more images
destination_folder = r'C:\Users\Ravindra Kanchu\Desktop\tshirt_f'  # The new folder to store selected images

# Ensure the destination folder exists
os.makedirs(destination_folder, exist_ok=True)

# List all the images in the tshirt_folder
tshirt_images = sorted(os.listdir(tshirt_folder))
print(f"Found {len(tshirt_images)} images in the tshirt_folder.")

# Ensure we have exactly 1287 images in the tshirt_folder
if len(tshirt_images) != 1288:
    print(f"Error: The tshirt folder does not contain exactly 1287 images (found {len(tshirt_images)}).")
    exit()

# List all the images in the source_folder
source_images = sorted(os.listdir(source_folder))
print(f"Found {len(source_images)} images in the source_folder.")

# Randomly select 1287 images from the source folder
selected_images = random.sample(source_images, 1287)

# Copy selected images to the destination folder with names from the tshirt_folder
for i, src_image in enumerate(selected_images):
    src_image_path = os.path.join(source_folder, src_image)
    dst_image_name = tshirt_images[i]
    dst_image_path = os.path.join(destination_folder, dst_image_name)
    
    try:
        shutil.copy(src_image_path, dst_image_path)
        print(f"Copied {src_image} to {dst_image_name}")
    except Exception as e:
        print(f"Failed to copy {src_image} to {dst_image_name}: {e}")

print(f"Successfully copied 1287 images to {destination_folder}.")
